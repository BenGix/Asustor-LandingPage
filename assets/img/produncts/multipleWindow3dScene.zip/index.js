import './style.css'
import * as module from './src/main.js'

document.querySelector('#app').innerHTML = `
<style type="text/css">
    *
    {
        margin: 0;
        padding: 0;
    }
</style>
    <div id="app"></div>
`
