# multipleWindow3dScene
A quick example of how one can "synchronize" a 3d scene across multiple windows using three.js and localStorage
